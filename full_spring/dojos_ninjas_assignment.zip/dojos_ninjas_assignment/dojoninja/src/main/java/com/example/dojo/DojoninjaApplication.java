package com.example.dojo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DojoninjaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DojoninjaApplication.class, args);
	}

}
